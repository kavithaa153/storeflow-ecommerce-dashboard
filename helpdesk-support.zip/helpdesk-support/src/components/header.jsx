import { Bell, Menu, Search, ChevronDown } from "lucide-react";
import "./Header.css";

function Header() {
  const currentUser = JSON.parse(
    localStorage.getItem("supportmateCurrentUser")
  );

  const userName = currentUser?.name || "Support Admin";
  const userRole = currentUser?.role || "Administrator";

  return (
    <header className="header">
      <div className="header-left">
        <button type="button" className="header-menu-button">
          <Menu size={20} />
        </button>

        <div className="header-search">
          <Search size={17} />
          <input
            type="text"
            placeholder="Search tickets, users, or anything..."
          />
        </div>
      </div>

      <div className="header-right">
        <button type="button" className="header-icon-button">
          <Bell size={18} />
          <span className="notification-count">3</span>
        </button>

        <div className="header-user">
          <div className="user-avatar">
            {userName.charAt(0).toUpperCase()}
          </div>

          <div className="user-info">
            <strong>{userName}</strong>
            <span>{userRole}</span>
          </div>

          <ChevronDown size={16} />
        </div>
      </div>
    </header>
  );
}

export default Header;
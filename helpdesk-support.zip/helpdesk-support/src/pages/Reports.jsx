import { useMemo, useState } from "react";
import {
  BarChart3,
  CheckCircle2,
  Clock3,
  Ticket,
  AlertTriangle
} from "lucide-react";
import { useHelpdesk } from "../context/HelpdeskContext";
import "./Reports.css";

function Reports() {
  const { tickets, isLoading, error } = useHelpdesk();

  const [period, setPeriod] = useState("This Month");

  const statistics = useMemo(() => {
    const total = tickets.length;

    const resolved = tickets.filter(
      (ticket) =>
        ticket.status === "Resolved" ||
        ticket.status === "Closed"
    ).length;

    const open = tickets.filter(
      (ticket) =>
        ticket.status === "Open" ||
        ticket.status === "Assigned" ||
        ticket.status === "In Progress"
    ).length;

    return {
      total,
      resolved,
      open
    };
  }, [tickets]);

  const categoryData = useMemo(() => {
    const categories = [
      "Technical",
      "Billing",
      "Account"
    ];

    return categories.map((category) => ({
      category,
      count: tickets.filter(
        (ticket) => ticket.category === category
      ).length
    }));
  }, [tickets]);

  const priorityData = useMemo(() => {
    const priorities = [
      "Critical",
      "High",
      "Medium",
      "Low"
    ];

    return priorities.map((priority) => ({
      priority,
      count: tickets.filter(
        (ticket) => ticket.priority === priority
      ).length
    }));
  }, [tickets]);

  const maxCategory = Math.max(
    ...categoryData.map((item) => item.count),
    1
  );

  const maxPriority = Math.max(
    ...priorityData.map((item) => item.count),
    1
  );

  if (isLoading) {
    return (
      <div className="reports-page">
        <div className="reports-loading">
          Loading reports...
        </div>
      </div>
    );
  }

  return (
    <div className="reports-page">
      <div className="reports-header">
        <div>
          <span className="reports-eyebrow">
            SUPPORT ANALYTICS
          </span>

          <h1>Reports & Analytics</h1>

          <p>
            Analyze ticket volume, priorities,
            categories and support performance.
          </p>
        </div>

        <select
          value={period}
          onChange={(event) =>
            setPeriod(event.target.value)
          }
          className="reports-period-select"
        >
          <option>This Month</option>
          <option>Last Month</option>
          <option>Last 3 Months</option>
        </select>
      </div>

      {error && (
        <div className="reports-error">
          {error}
        </div>
      )}

      <div className="reports-stat-grid">
        <div className="reports-stat-card">
          <div className="reports-stat-icon">
            <Ticket size={20} />
          </div>

          <span>Total Tickets</span>
          <strong>{statistics.total}</strong>
        </div>

        <div className="reports-stat-card">
          <div className="reports-stat-icon">
            <CheckCircle2 size={20} />
          </div>

          <span>Resolved Tickets</span>
          <strong>{statistics.resolved}</strong>
        </div>

        <div className="reports-stat-card">
          <div className="reports-stat-icon">
            <Clock3 size={20} />
          </div>

          <span>Open Tickets</span>
          <strong>{statistics.open}</strong>
        </div>

        <div className="reports-stat-card">
          <div className="reports-stat-icon">
            <AlertTriangle size={20} />
          </div>

          <span>SLA Performance</span>
          <strong>87%</strong>
        </div>
      </div>

      <div className="reports-grid">
        <section className="reports-card">
          <div className="reports-card-header">
            <div>
              <h2>Tickets by Category</h2>
              <p>Support requests grouped by category.</p>
            </div>

            <BarChart3 size={19} />
          </div>

          <div className="reports-chart-list">
            {categoryData.map((item) => (
              <div
                className="reports-chart-row"
                key={item.category}
              >
                <div className="reports-chart-label">
                  <span>{item.category}</span>
                  <strong>{item.count}</strong>
                </div>

                <div className="reports-chart-track">
                  <div
                    className="reports-chart-fill"
                    style={{
                      width: `${
                        (item.count / maxCategory) * 100
                      }%`
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>

        <section className="reports-card">
          <div className="reports-card-header">
            <div>
              <h2>Tickets by Priority</h2>
              <p>Ticket distribution by priority.</p>
            </div>

            <AlertTriangle size={19} />
          </div>

          <div className="reports-chart-list">
            {priorityData.map((item) => (
              <div
                className="reports-chart-row"
                key={item.priority}
              >
                <div className="reports-chart-label">
                  <span>{item.priority}</span>
                  <strong>{item.count}</strong>
                </div>

                <div className="reports-chart-track">
                  <div
                    className="reports-chart-fill"
                    style={{
                      width: `${
                        (item.count / maxPriority) * 100
                      }%`
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>

      <section className="reports-card">
        <div className="reports-card-header">
          <div>
            <h2>Ticket Volume</h2>
            <p>Current ticket status distribution.</p>
          </div>
        </div>

        <div className="reports-volume">
          {[
            "Open",
            "Assigned",
            "In Progress",
            "Pending",
            "Resolved",
            "Closed",
            "Cancelled"
          ].map((status) => {
            const count = tickets.filter(
              (ticket) => ticket.status === status
            ).length;

            return (
              <div
                className="reports-volume-item"
                key={status}
              >
                <strong>{count}</strong>
                <span>{status}</span>
              </div>
            );
          })}
        </div>
      </section>
    </div>
  );
}

export default Reports;
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./Login.css";

function Login() {
  const navigate = useNavigate();

  const [email, setEmail] = useState(
    localStorage.getItem("rememberedEmail") || ""
  );
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(
    Boolean(localStorage.getItem("rememberedEmail"))
  );

  const [emailError, setEmailError] = useState("");
  const [passwordError, setPasswordError] = useState("");
  const [loginError, setLoginError] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  const [emailTouched, setEmailTouched] = useState(false);
  const [passwordTouched, setPasswordTouched] = useState(false);

  const validateEmail = (value) => {
    if (!value.trim()) {
      return "Email is required";
    }

    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
      return "Please enter a valid email address";
    }

    return "";
  };

  const validatePassword = (value) => {
    if (!value.trim()) {
      return "Password is required";
    }

    if (value.length < 6) {
      return "Password must be at least 6 characters";
    }

    return "";
  };

  const handleEmailChange = (event) => {
    const value = event.target.value;

    setEmail(value);
    setLoginError("");

    if (emailTouched) {
      setEmailError(validateEmail(value));
    }
  };

  const handlePasswordChange = (event) => {
    const value = event.target.value;

    setPassword(value);
    setLoginError("");

    if (passwordTouched) {
      setPasswordError(validatePassword(value));
    }
  };

  const handleEmailBlur = () => {
    setEmailTouched(true);
    setEmailError(validateEmail(email));
  };

  const handlePasswordBlur = () => {
    setPasswordTouched(true);
    setPasswordError(validatePassword(password));
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    setEmailTouched(true);
    setPasswordTouched(true);

    const emailValidation = validateEmail(email);
    const passwordValidation = validatePassword(password);

    setEmailError(emailValidation);
    setPasswordError(passwordValidation);
    setLoginError("");

    if (emailValidation || passwordValidation) {
      return;
    }

    setIsLoading(true);

    setTimeout(() => {
      const registeredUser = JSON.parse(
        localStorage.getItem("supportmateUser")
      );

      const demoEmail = "supportmate@example.com";
      const demoPassword = "Support@123";

      const isRegisteredUserValid =
        registeredUser &&
        registeredUser.email === email &&
        registeredUser.password === password;

      const isDemoUserValid =
        email === demoEmail && password === demoPassword;

      if (isRegisteredUserValid || isDemoUserValid) {
        const loggedInUser = isRegisteredUserValid
          ? {
              name: registeredUser.name,
              email: registeredUser.email,
              role: registeredUser.role || "Support Agent"
            }
          : {
              name: "Support Admin",
              email: demoEmail,
              role: "Administrator"
            };

        localStorage.setItem(
          "supportmateCurrentUser",
          JSON.stringify(loggedInUser)
        );

        if (rememberMe) {
          localStorage.setItem("rememberedEmail", email);
        } else {
          localStorage.removeItem("rememberedEmail");
        }

        navigate("/dashboard");
      } else {
        setLoginError("Invalid email or password");
      }

      setIsLoading(false);
    }, 700);
  };

  const handleCreateAccount = () => {
    navigate("/register");
  };

  return (
    <div className="login-page">
      <div className="login-container">
        <section className="login-brand-panel">
          <div className="brand-content">
            <span className="brand-label">HELPDESK PLATFORM</span>

            <h1 className="brand-title">SupportMate</h1>

            <p className="brand-tagline">
              Support smarter. Resolve faster.
            </p>

            <p className="brand-description">
              A centralized workspace for managing customer support tickets,
              teams, SLAs, and customer conversations.
            </p>

            <div className="brand-highlights">
              <div className="brand-highlight">
                <span className="highlight-number">24/7</span>
                <span className="highlight-text">Support Operations</span>
              </div>

              <div className="brand-highlight">
                <span className="highlight-number">99%</span>
                <span className="highlight-text">Ticket Visibility</span>
              </div>
            </div>
          </div>
        </section>

        <section className="login-form-panel">
          <div className="login-content">
            <div className="login-header">
              <span className="login-welcome-label">WELCOME BACK</span>

              <h2 className="login-title">Sign in to SupportMate</h2>

              <p className="login-subtitle">
                Access your support workspace and manage your tickets.
              </p>
            </div>

            <form className="login-form" onSubmit={handleSubmit}>
              <div className="form-group">
                <label className="form-label" htmlFor="email">
                  Email Address
                </label>

                <input
                  id="email"
                  type="email"
                  className={`form-input ${
                    emailError ? "form-input-error" : ""
                  }`}
                  value={email}
                  onChange={handleEmailChange}
                  onBlur={handleEmailBlur}
                  placeholder="Enter your email"
                  autoComplete="email"
                />

                {emailError && (
                  <p className="form-error">{emailError}</p>
                )}
              </div>

              <div className="form-group">
                <label className="form-label" htmlFor="password">
                  Password
                </label>

                <div className="password-input-wrapper">
                  <input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    className={`form-input password-input ${
                      passwordError ? "form-input-error" : ""
                    }`}
                    value={password}
                    onChange={handlePasswordChange}
                    onBlur={handlePasswordBlur}
                    placeholder="Enter your password"
                    autoComplete="current-password"
                  />

                  <button
                    type="button"
                    className="password-toggle-button"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? "Hide" : "Show"}
                  </button>
                </div>

                {passwordError && (
                  <p className="form-error">{passwordError}</p>
                )}
              </div>

              <div className="login-options">
                <label className="remember-me">
                  <input
                    type="checkbox"
                    className="remember-checkbox"
                    checked={rememberMe}
                    onChange={(event) =>
                      setRememberMe(event.target.checked)
                    }
                  />
                  <span>Remember me</span>
                </label>

                <button
                  type="button"
                  className="forgot-password-link"
                  onClick={() => navigate("/forgot-password")}
                >
                  Forgot password?
                </button>
              </div>

              {loginError && (
                <div className="login-error-message">
                  {loginError}
                </div>
              )}

              <button
                type="submit"
                className="login-submit-button"
                disabled={isLoading}
              >
                {isLoading ? "Signing In..." : "Sign In"}
              </button>
            </form>

            <div className="login-demo-info">
              <span className="demo-info-label">Demo Login</span>
              <span>supportmate@example.com</span>
              <span>Support@123</span>
            </div>

            <div className="login-footer">
              <span>Don't have an account?</span>

              <button
                type="button"
                className="register-link"
                onClick={handleCreateAccount}
              >
                Create account
              </button>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

export default Login;